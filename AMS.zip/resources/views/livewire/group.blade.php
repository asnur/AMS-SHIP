<?php
$no = 1;
?>


@push('main_group')
    <script>
        // $('#main_group_list').on('change', function(e) {
        //     var data = $('#main_group_list').select2("val");
        //     @this.set('main_group_list', data);
        //     // $('#main_group_list').select2("val");
        // });
        // Livewire.on('datatables', function() {
        //     $('#main_group_list').select2({
        //         theme: 'bootstrap4',
        //     });
        //     $('#group_list').select2({
        //         theme: 'bootstrap4',
        //     });
        // })
    </script>
@endpush
