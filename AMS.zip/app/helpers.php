<?php

use App\Models\Group;

function name_taskjob(int $id)
{
    return Group::where('kode', $id)->first();
}
