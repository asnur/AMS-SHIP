<?php

namespace App\Http\Livewire;

use Livewire\Component;
use Illuminate\Support\Facades\DB;

class Group extends Component
{

    public $main_group_list;
    public $group_list;

    public function render()
    {
        $main_group = DB::table('tbl_group')->whereRaw('LENGTH(kode) = 1')->get();
        $group = DB::table('tbl_group')->where('kode1', $this->main_group_list)->whereRaw('LENGTH(kode) = 2')->get();

        return view('livewire.group', compact(['main_group', 'group']));
    }

    public function datatables()
    {
        $this->emit('datatables');
    }
}
