
<?php $__env->startSection('content'); ?>
    <?php
    $no = 1;
    ?>

    <div class="container-fluid">
        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Edit User</h1>
            
            
        </div>

        
        <div class="row">
            <div class="col-12">

                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('update-user', $user->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <label class="font-weight-bold">Username</label>
                            <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>"
                                placeholder="Input Username...." required>
                            <label class="font-weight-bold mt-3">Email</label>
                            <input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>"
                                placeholder="Input Email...." required>
                            <label class="font-weight-bold mt-3">New Password</label>
                            <input type="password" class="form-control" name="password" placeholder="Input Password....">
                            <label class="font-weight-bold mt-3">Role</label>
                            <select class="form-control" name="roles" id="roles">
                                <option>- Choose Role -</option>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($r); ?>" <?php echo e($userRoles == $r ? 'selected' : ''); ?>>
                                        <?php echo e($r); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <button type="submit" class="btn btn-success mt-3"><i class="fa fa-paper-plane"></i>
                                Send</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell E7440\Desktop\AMS\resources\views/pages/admin/edit_user.blade.php ENDPATH**/ ?>