 
 <?php $__env->startSection('content'); ?>
     <?php
     $no = 1;
     ?>
     <div>
         <div class="container-fluid">

             <!-- Page Heading -->
             <div class="d-sm-flex align-items-center justify-content-between mb-4">
                 <h1 class="h3 mb-0 text-gray-800">Main Group</h1>
                 
             </div>

             <!-- Content Row -->
             <div class="row">
                 <div class="col-12">
                     <div class="card">
                         <div class="card-body">
                             <div class="row">
                                 <div class="col-12 mb-3">
                                     <label class="font-weight-bold">Main Group</label>
                                     <select class="form-control" id="main_group_list">
                                         <option> --- Choose Main Group --- </option>
                                         <?php $__currentLoopData = $main_group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($mg->kode); ?>"><?php echo e($mg->kode); ?>-<?php echo e($mg->name); ?>

                                             </option>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     </select><br>
                                 </div>
                                 
                                 <div class="col-3">
                                     <label class="font-weight-bold">Group</label>
                                     <select class="form-control" id="group_list">
                                         <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($g->kode); ?>" class="<?php echo e($g->kode1); ?>">
                                                 <?php echo e($g->kode); ?>-<?php echo e($g->name); ?></option>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     </select>
                                 </div>
                                 <div class="col-3">
                                     <label class="font-weight-bold">Sub Group</label>
                                     <select class="form-control" id="sub_group_list">
                                         <?php $__currentLoopData = $sub_group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($sg->kode); ?>" class="<?php echo e($sg->kode2); ?>">
                                                 <?php echo e($sg->kode); ?>-<?php echo e($sg->name); ?></option>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     </select>
                                 </div>
                                 <div class="col-3">
                                     <label class="font-weight-bold">Unit</label>
                                     <select class="form-control" id="unit_list">
                                         <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($u->kode); ?>" class="<?php echo e($u->kode3); ?>">
                                                 <?php echo e($u->kode); ?>-<?php echo e($u->name); ?></option>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     </select>
                                 </div>
                                 <div class="col-3">
                                     <label class="font-weight-bold">Component</label>
                                     <select class="form-control" id="component_list">
                                         <?php $__currentLoopData = $component; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($c->kode); ?>" class="<?php echo e($c->kode4); ?>">
                                                 <?php echo e($c->kode); ?>-<?php echo e($c->name); ?></option>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     </select>
                                 </div>
                                 <div class="col-12 text-right mt-5">
                                     <a class="btn btn-success" id="filter"><i class="fa fa-filter"></i> Detail</a>
                                 </div>
                                 <div class="col-12 mt-5 data-main-group">
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>

             </div>
         </div>
     <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell E7440\Desktop\AMS\resources\views/pages/admin/group.blade.php ENDPATH**/ ?>