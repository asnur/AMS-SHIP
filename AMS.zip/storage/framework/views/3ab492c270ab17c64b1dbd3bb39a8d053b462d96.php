
<?php $__env->startSection('content'); ?>
    <?php
    $no = 1;
    ?>

    <div class="container-fluid">
        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">PMS</h1>
            
            
        </div>

        <form action="<?php echo e(route('assign-pms')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="modal fade" id="prosesPMS" data-backdrop="static" data-keyboard="false" tabindex="-1"
                aria-labelledby="staticBackdropLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header text-white bg-primary">
                            <h5 class="modal-title" id="staticBackdropLabel">Proses PMS <span id="name-pms"></span></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" name="id_taskjob" id="id-pms">
                            <label class="font-weight-bold">Image 1 (Optional)</label>
                            <div class="custom-file">
                                <input type="file" name="image_1" class="custom-file-input" id="image1" accept="image/*"
                                    onchange="previewImage_1(this)">
                                <label class="custom-file-label" for="customFile">Choose file</label>
                            </div>
                            <img src="#" id="image_1" class="mt-2"
                                style="width: 350px; height:200px; object-fit:cover;"><br>
                            <label class="font-weight-bold mt-2">Image 2
                                (Optional)</label>
                            <div class="custom-file">
                                <input type="file" name="image_2" class="custom-file-input" id="image2" accept="image/*"
                                    onchange="previewImage_2(this)">
                                <label class="custom-file-label" for="customFile">Choose file</label>
                            </div>
                            <img src="#" id="image_2" class="mt-2"
                                style="width: 350px; height:200px; object-fit:cover;"><br>
                            <label class="font-weight-bold mt-2">Image 3 (Optional)</label>
                            <div class="custom-file">
                                <input type="file" name="image_3" class="custom-file-input" id="image3" accept="image/*"
                                    onchange="previewImage_3(this)">
                                <label class="custom-file-label" for="customFile">Choose file</label>
                            </div>
                            <img src="#" id="image_3" class="mt-2"
                                style="width: 350px; height:200px; object-fit:cover;"><br>
                            <label class="font-weight-bold mt-2">Date Action</label>
                            <input type="date" class="form-control" name="date_action">
                            <label class="font-weight-bold mt-2">Action</label>
                            <textarea class="form-control" id="action-pms" name="action"></textarea>
                        </div>
                        <div class="modal-footer bg-primary">
                            <button type="submit" class="btn btn-success"><i class="fa fa-paper-plane"></i>
                                Send</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>

        
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link font-weight-bold text-primary active" id="home-tab" data-toggle="tab"
                                    href="#home" role="tab" aria-controls="home" aria-selected="true">Upcoming</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link font-weight-bold text-primary" id="profile-tab" data-toggle="tab"
                                    href="#profile" role="tab" aria-controls="profile" aria-selected="false">Ongoing</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link font-weight-bold text-primary" id="contact-tab" data-toggle="tab"
                                    href="#contact" role="tab" aria-controls="contact" aria-selected="false">Finished</a>
                            </li>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                <br>
                                <div class="category-filter-upcoming">
                                    <select id="categoryFilterUpcoming" class="form-control">
                                        <option value="">All</option>
                                        <option value="No-Critical">No Critical</option>
                                        <option value="Critical !!!">Critical</option>
                                    </select>
                                </div>
                                <table class="table table-striped" id="table-listtaskjob-upcoming">
                                    <thead>
                                        <th>No</th>
                                        <th>Code Name</th>
                                        <th>Job Desk</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </thead>
                                    <tfoot>
                                        <th>No</th>
                                        <th>Code Name</th>
                                        <th>Job Desk</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tfoot>
                                    <tbody>
                                        <?php $__currentLoopData = $upcoming; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($no++); ?></td>
                                                <td><?php echo e($u->kode . '-' . $u->group->name); ?></td>
                                                <td><?php echo $u->jobdesk; ?></td>
                                                <td><?php echo $u->critical == 0 ? '<label class="badge badge-success p-2">No-Critical</label>' : '<label class="badge badge-danger p-2">Critical !!!</label>'; ?>

                                                </td>
                                                <td>
                                                    <form action="<?php echo e(route('open-pms')); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PATCH'); ?>
                                                        <input type="hidden" name="id" value="<?php echo e($u->id); ?>">
                                                        <button class="btn btn-sm btn-success" type="submit"><i
                                                                class="fa fa-play"></i></button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="
                                                            tab-pane fade"
                                id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                <br>
                                <div class="category-filter">
                                    <select id="categoryFilterOngoing" class="form-control">
                                        <option value="">All</option>
                                        <option value="No-Critical">No Critical</option>
                                        <option value="Critical !!!">Critical</option>
                                    </select>
                                </div>
                                <table class="table table-striped" id="table-listtaskjob-ongoing">
                                    <thead>
                                        <th>No</th>
                                        <th>Code Name</th>
                                        <th>Job Desk</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </thead>
                                    <tfoot>
                                        <th>No</th>
                                        <th>Code Name</th>
                                        <th>Job Desk</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tfoot>
                                    <tbody>
                                        <?php $__currentLoopData = $ongoing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($no++); ?></td>
                                                <td><?php echo e($o->kode . '-' . $o->group->name); ?></td>
                                                <td><?php echo $o->jobdesk; ?></td>
                                                <td><?php echo $o->critical == 0 ? '<label class="badge badge-success p-2">No-Critical</label>' : '<label class="badge badge-danger p-2">Critical !!!</label>'; ?>

                                                </td>
                                                <td>
                                                    <a class="btn btn-sm btn-primary" data-toggle="modal"
                                                        data-target="#prosesPMS"
                                                        onclick="prosesPMS(<?php echo e($o->id); ?>, '<?php echo e($o->kode . '-' . $o->group->name); ?>')"><i
                                                            class="fa fa-cogs"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                                <br>
                                <div class="category-filter">
                                    <select id="categoryFilterFinished" class="form-control">
                                        <option value="">All</option>
                                        <option value="No-Critical">No Critical</option>
                                        <option value="Critical !!!">Critical</option>
                                    </select>
                                </div>
                                <table class="table table-striped" id="table-listtaskjob-finished">
                                    <thead>
                                        <th>No</th>
                                        <th>Code Name</th>
                                        <th>Job Desk</th>
                                        <th>Approve</th>
                                        <th>Status</th>
                                    </thead>
                                    <tfoot>
                                        <th>No</th>
                                        <th>Code Name</th>
                                        <th>Job Desk</th>
                                        <th>Approve</th>
                                        <th>Status</th>
                                    </tfoot>
                                    <tbody>
                                        <?php $__currentLoopData = $finished; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($no++); ?></td>
                                                <td><?php echo e($f->kode . '-' . $f->group->name); ?></td>
                                                <td><?php echo $f->jobdesk; ?></td>
                                                <td><?php echo $f->critical == 0 ? '<label class="badge badge-success p-2">No-Critical</label>' : '<label class="badge badge-danger p-2">Critical !!!</label>'; ?>

                                                </td>
                                                <td>test</td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell E7440\Desktop\AMS\resources\views/pages/admin/pms.blade.php ENDPATH**/ ?>