
<?php $__env->startSection('content'); ?>
    <?php
    $no = 1;
    ?>

    <div class="container-fluid">
        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Role Management</h1>
            <a href="<?php echo e(route('role-add')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-success shadow-sm"><i
                    class="fas fa-plus fa-sm text-white-50"></i> Create Role</a>
            
        </div>

        
        <div class="row">
            <div class="col-12">

                <div class="card">
                    <div class="card-body" id="value-taskjob">
                        <table class="table table-striped " id="table">
                            <thead>
                                <th>No</th>
                                <th>Name</th>
                                <th>Action</th>
                            </thead>
                            <tfoot>
                                <th>No</th>
                                <th>Name</th>
                                <th>Action</th>
                            </tfoot>
                            <tbody>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <td><?php echo e($r->name); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('edit-role', $r->id)); ?>" class="btn btn-sm btn-primary"><i
                                                    class="fa fa-edit"></i></a>
                                            <form action="<?php echo e(route('delete-role', $r->id)); ?>" class="d-inline"
                                                method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger"><i
                                                        class="fa fa-trash"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell E7440\Desktop\AMS\resources\views/pages/admin/role.blade.php ENDPATH**/ ?>