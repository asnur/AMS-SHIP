
<?php $__env->startSection('content'); ?>
    <?php
    $no = 1;
    ?>

    <div class="container-fluid">
        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Edit Taskjob</h1>
            
            
        </div>

        
        <div class="row">
            <div class="col-12">

                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('update-taskjob')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <input type="hidden" value="<?php echo e($taskjob->id); ?>" name="id">
                            <label for="kode" class="font-weight-bold">Code Name</label>
                            <select class="form-control" name="kode" id="kode" required>
                                <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($g->kode); ?>"
                                        <?php echo e($g->kode == $taskjob->kode ? 'selected' : ''); ?>>
                                        <?php echo e($g->kode . '-' . $g->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="kode" class="font-weight-bold mt-3">Group</label>
                            <select class="form-control" name="group_id" id="group_id" required>
                                <?php $__currentLoopData = $group_taskjob; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($gt->id); ?>"
                                        <?php echo e($gt->id == $taskjob->group_id ? 'selected' : ''); ?>><?php echo e($gt->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="" class="font-weight-bold mt-3">Job Desk</label>
                            <textarea class="form-control" name="jobdesk" id="jobdesk" rows="5"
                                placeholder="Input Jobdesk" required><?php echo $taskjob->jobdesk; ?></textarea>
                            <label for="" class="font-weight-bold mt-3">Cost Estimation</label>
                            <input class="form-control" type="number" name="cost" id="cost"
                                placeholder="Input Cost Estimation" value="<?php echo e($taskjob->cost); ?>" required>
                            <label for="" class="font-weight-bold mt-3">Freq</label>
                            <input class="form-control" type="number" value="<?php echo e($taskjob->freq); ?>" name="freq" id="freq"
                                placeholder="Input number of frequencies" required>
                            <label for="" class="font-weight-bold mt-3">Freq Interval</label>
                            <select class="form-control" name="id_freq" name="id_freq" required>
                                <?php $__currentLoopData = $freq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($f->name); ?>"
                                        <?php echo e($f->name == $taskjob->id_freq ? 'selected' : ''); ?>>
                                        <?php echo e($f->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="" class="font-weight-bold mt-3">Interval Running Hour</label>
                            <input class="form-control" type="number" name="interval"
                                placeholder="Input number of interval" value="<?php echo e($taskjob->interval); ?>" required>
                            <label for="" class="font-weight-bold mt-3">Due Date (optional)</label>
                            <input class="form-control" type="date" name="due_date" placeholder="Input number of interval"
                                value="<?php echo e(date('Y-m-d', strtotime($taskjob->due_date))); ?>" required>
                            <label for="" class="font-weight-bold mt-3">Critical</label><br>
                            <input type="radio" name="critical" value="1" <?php echo e($taskjob->critical == 1 ? 'checked' : ''); ?>

                                required> Yes
                            <input type="radio" name="critical" value="0" <?php echo e($taskjob->critical == 0 ? 'checked' : ''); ?>

                                required> No
                    </div>
                </div>
                <button
                    type="
                                                                                                                                                                                        submit"
                    class="btn btn-success mt-3"><i class="fa fa-paper-plane"></i>Send</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell E7440\Desktop\AMS\resources\views/pages/admin/edit_taskjob.blade.php ENDPATH**/ ?>