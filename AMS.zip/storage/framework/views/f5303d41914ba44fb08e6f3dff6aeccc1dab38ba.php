
<?php $__env->startSection('content'); ?>
    <?php
    $no = 1;
    ?>

    <div class="container-fluid">
        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Edit Role</h1>
            
            
        </div>

        
        <div class="row">
            <div class="col-12">

                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('update-role', $role->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <label class="font-weight-bold">Name</label>
                            <input type="text" class="form-control" name="name" value="<?php echo e($role->name); ?>"
                                placeholder="Input Name Role...." required>
                            <label class="font-weight-bold mt-3">Permission</label>
                            <div class="form-check">
                                <div class="row">
                                    <div class="col-4">
                                        <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <input type="checkbox" class="form-check-input" name="permission[]"
                                                value="<?php echo e($p->name); ?>"
                                                <?php echo e(in_array($p->id, $rolePermissions) ? 'checked' : ''); ?>><?php echo e($p->name); ?><br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-success mt-3"><i class="fa fa-paper-plane"></i>
                    Send</button>
                </form>
            </div>
        </div>
    </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell E7440\Desktop\AMS\resources\views/pages/admin/edit_role.blade.php ENDPATH**/ ?>