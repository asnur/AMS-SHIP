
<?php $__env->startSection('content'); ?>
    <?php
    $no = 1;
    ?>

    <div class="container-fluid">
        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">User Management</h1>
            <?php if(auth()->user()->can('create user')): ?>
                <a href="<?php echo e(route('user-add')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-success shadow-sm"><i
                        class="fas fa-plus fa-sm text-white-50"></i> Create User</a>
            <?php endif; ?>
            
        </div>

        
        <div class="row">
            <div class="col-12">

                <div class="card">
                    <div class="card-body" id="value-taskjob">
                        <table class="table table-striped " id="table">
                            <thead>
                                <th>No</th>
                                <th>Name</th>
                                <th>E-Mail</th>
                                <th>Roles</th>
                                <?php if(auth()->user()->can('edit user') ||
        auth()->user()->can('delete user')): ?>
                                    <th>Action</th>
                                <?php endif; ?>
                            </thead>
                            <tfoot>
                                <th>No</th>
                                <th>Name</th>
                                <th>E-Mail</th>
                                <th>Roles</th>
                                <?php if(auth()->user()->can('edit user') ||
        auth()->user()->can('delete user')): ?>
                                    <th>Action</th>
                                <?php endif; ?>
                            </tfoot>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <td><?php echo e($v->name); ?></td>
                                        <td><?php echo e($v->email); ?></td>
                                        <td>
                                            <?php if(!empty($v->getRoleNames())): ?>
                                                <?php $__currentLoopData = $v->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <label class="badge badge-success"><?php echo e($role); ?></label>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </td>
                                        <?php if(auth()->user()->can('edit user') ||
        auth()->user()->can('delete user')): ?>
                                            <td>
                                                <?php if(auth()->user()->can('edit user')): ?>
                                                    <a href="<?php echo e(route('edit-user', $v->id)); ?>"
                                                        class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></a>
                                                <?php endif; ?>
                                                <?php if(auth()->user()->can('delete user')): ?>
                                                    <form action="<?php echo e(route('delete-user', $v->id)); ?>"
                                                        class="d-inline" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-sm btn-danger"><i
                                                                class="fa fa-trash"></i></button>
                                                    </form>
                                                <?php endif; ?>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell E7440\Desktop\AMS\resources\views/pages/admin/user.blade.php ENDPATH**/ ?>